package com.excel.demo.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.excel.demo.project.entity.ExcelData;
import com.excel.demo.project.helper.ExcelHelper;
import com.excel.demo.project.repo.ExcelRepo;

@Service
public class ExcelService {
	@Autowired
	private ExcelRepo sourcingRepo;
	
	
	public void save(MultipartFile file)
	{
		try
		{
			List<ExcelData> sourceData = ExcelHelper.convertExceltoList(file.getInputStream());
			this.sourcingRepo.saveAll(sourceData);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public List<ExcelData> getAllData()
	{
		return this.sourcingRepo.findAll();
	}

}
