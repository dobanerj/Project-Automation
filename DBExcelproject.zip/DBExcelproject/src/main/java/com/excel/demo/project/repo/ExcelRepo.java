package com.excel.demo.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.excel.demo.project.entity.ExcelData;

@Repository
public interface ExcelRepo extends JpaRepository<ExcelData,Integer>{

}
