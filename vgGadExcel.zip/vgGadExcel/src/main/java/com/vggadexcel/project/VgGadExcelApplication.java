package com.vggadexcel.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VgGadExcelApplication {

	public static void main(String[] args) {
		SpringApplication.run(VgGadExcelApplication.class, args);
	}

}
