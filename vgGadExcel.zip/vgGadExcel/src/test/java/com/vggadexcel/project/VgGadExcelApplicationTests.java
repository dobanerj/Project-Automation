package com.vggadexcel.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VgGadExcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
